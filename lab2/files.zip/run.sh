#!/bin/bash
# =============================================================
# Скрипт збірки та запуску Messenger API
# Вимоги: Java 17+ (JDK)
# =============================================================

set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
OUT_DIR="$PROJECT_DIR/out"
SRC_MAIN="$PROJECT_DIR/src/main/java"
SRC_TEST="$PROJECT_DIR/src/test/java"

echo "================================================"
echo "  Messenger API — Збірка та запуск"
echo "================================================"

# Перевірка наявності javac
if ! command -v javac &> /dev/null; then
  echo "ПОМИЛКА: javac не знайдено. Встановіть JDK 17+"
  exit 1
fi

JAVA_VER=$(java -version 2>&1 | head -1)
echo "Java: $JAVA_VER"

# Компіляція
echo ""
echo "Компіляція..."
mkdir -p "$OUT_DIR"

find "$SRC_MAIN" -name "*.java" | xargs javac -encoding UTF-8 -d "$OUT_DIR"
echo "  ✓ Основний код скомпільовано"

find "$SRC_TEST" -name "*.java" | xargs javac -encoding UTF-8 -cp "$OUT_DIR" -d "$OUT_DIR"
echo "  ✓ Тести скомпільовано"

# Режим запуску
MODE="${1:-server}"

if [ "$MODE" = "test" ]; then
  echo ""
  echo "Запуск інтеграційних тестів..."
  echo "------------------------------------------------"
  java -cp "$OUT_DIR" com.messenger.IntegrationTest
else
  echo ""
  echo "Запуск сервера на порту 8080..."
  echo "Зупинити: Ctrl+C"
  echo "------------------------------------------------"
  mkdir -p "$PROJECT_DIR/data"
  java -cp "$OUT_DIR" com.messenger.Main 8080 "$PROJECT_DIR/data"
fi
