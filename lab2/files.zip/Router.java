package com.messenger.api;

import com.messenger.models.Conversation;
import com.messenger.models.Message;
import com.messenger.models.User;
import com.messenger.services.MessageService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * HTTP API — маршрутизатор запитів.
 *
 * Маршрути:
 *   POST   /users                              — створити користувача
 *   GET    /users                              — список користувачів
 *   POST   /conversations                      — створити розмову
 *   GET    /conversations                      — список розмов
 *   POST   /messages                           — надіслати повідомлення
 *   GET    /conversations/{id}/messages        — отримати історію
 *   PATCH  /messages/{id}/status               — оновити статус (Варіант 2)
 */
public class Router {

    private final MessageService service;
    private final HttpServer server;

    public Router(MessageService service, int port) throws IOException {
        this.service = service;
        this.server  = HttpServer.create(new InetSocketAddress(port), 0);
        registerRoutes();
    }

    public void start() {
        server.start();
        System.out.println("Сервер запущено на порту " + server.getAddress().getPort());
    }

    public void stop() {
        server.stop(0);
    }

    private void registerRoutes() {
        server.createContext("/users",         this::handleUsers);
        server.createContext("/conversations", this::handleConversations);
        server.createContext("/messages",      this::handleMessages);
    }

    // ── /users ────────────────────────────────────────────────────────────────

    private void handleUsers(HttpExchange ex) throws IOException {
        String method = ex.getRequestMethod();
        try {
            if ("POST".equalsIgnoreCase(method)) {
                String body  = readBody(ex);
                String name  = extractJsonField(body, "name");
                User user    = service.createUser(name);
                sendJson(ex, 201, user.toString());

            } else if ("GET".equalsIgnoreCase(method)) {
                List<User> users = service.getAllUsers();
                String json = toJsonArray(users.stream()
                    .map(User::toString).collect(Collectors.toList()));
                sendJson(ex, 200, json);

            } else {
                sendJson(ex, 405, error("Метод не підтримується"));
            }
        } catch (IllegalArgumentException e) {
            sendJson(ex, 400, error(e.getMessage()));
        } catch (Exception e) {
            sendJson(ex, 500, error("Внутрішня помилка: " + e.getMessage()));
        }
    }

    // ── /conversations ────────────────────────────────────────────────────────

    private void handleConversations(HttpExchange ex) throws IOException {
        String path   = ex.getRequestURI().getPath();
        String method = ex.getRequestMethod();

        // GET /conversations/{id}/messages
        if ("GET".equalsIgnoreCase(method) && path.matches("/conversations/[^/]+/messages")) {
            String convId = path.split("/")[2];
            try {
                List<Message> messages = service.getMessages(convId);
                String json = toJsonArray(messages.stream()
                    .map(Message::toString).collect(Collectors.toList()));
                sendJson(ex, 200, json);
            } catch (IllegalArgumentException e) {
                sendJson(ex, 404, error(e.getMessage()));
            } catch (Exception e) {
                sendJson(ex, 500, error("Внутрішня помилка: " + e.getMessage()));
            }
            return;
        }

        try {
            if ("POST".equalsIgnoreCase(method)) {
                String body = readBody(ex);
                String type = extractJsonField(body, "type");
                if (type.isBlank()) type = "direct";
                Conversation conv = service.createConversation(type);
                sendJson(ex, 201, conv.toString());

            } else if ("GET".equalsIgnoreCase(method)) {
                List<Conversation> convs = service.getAllConversations();
                String json = toJsonArray(convs.stream()
                    .map(Conversation::toString).collect(Collectors.toList()));
                sendJson(ex, 200, json);

            } else {
                sendJson(ex, 405, error("Метод не підтримується"));
            }
        } catch (IllegalArgumentException e) {
            sendJson(ex, 400, error(e.getMessage()));
        } catch (Exception e) {
            sendJson(ex, 500, error("Внутрішня помилка: " + e.getMessage()));
        }
    }

    // ── /messages ─────────────────────────────────────────────────────────────

    private void handleMessages(HttpExchange ex) throws IOException {
        String path   = ex.getRequestURI().getPath();
        String method = ex.getRequestMethod();

        // PATCH /messages/{id}/status  (Варіант 2 — оновлення статусу)
        if ("PATCH".equalsIgnoreCase(method) && path.matches("/messages/[^/]+/status")) {
            String msgId = path.split("/")[2];
            try {
                String body   = readBody(ex);
                String status = extractJsonField(body, "status");
                boolean ok    = service.updateStatus(msgId, status);
                if (ok) {
                    sendJson(ex, 200, "{\"updated\":true,\"status\":\"" + status + "\"}");
                } else {
                    sendJson(ex, 404, error("Повідомлення не знайдено"));
                }
            } catch (IllegalArgumentException e) {
                sendJson(ex, 400, error(e.getMessage()));
            } catch (Exception e) {
                sendJson(ex, 500, error("Внутрішня помилка: " + e.getMessage()));
            }
            return;
        }

        try {
            if ("POST".equalsIgnoreCase(method)) {
                String body           = readBody(ex);
                String conversationId = extractJsonField(body, "conversationId");
                String senderId       = extractJsonField(body, "senderId");
                String text           = extractJsonField(body, "text");
                Message msg = service.sendMessage(conversationId, senderId, text);
                sendJson(ex, 201, msg.toString());

            } else {
                sendJson(ex, 405, error("Метод не підтримується"));
            }
        } catch (IllegalArgumentException e) {
            sendJson(ex, 400, error(e.getMessage()));
        } catch (Exception e) {
            sendJson(ex, 500, error("Внутрішня помилка: " + e.getMessage()));
        }
    }

    // ── Утиліти ───────────────────────────────────────────────────────────────

    private String readBody(HttpExchange ex) throws IOException {
        try (InputStream is = ex.getRequestBody()) {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private void sendJson(HttpExchange ex, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private String error(String msg) {
        return "{\"error\":\"" + msg.replace("\"", "\\\"") + "\"}";
    }

    private String toJsonArray(List<String> items) {
        return "[" + String.join(",", items) + "]";
    }

    /**
     * Простий вилучальник поля з JSON (без зовнішніх бібліотек).
     */
    private String extractJsonField(String json, String key) {
        if (json == null) return "";
        String search = "\"" + key + "\"";
        int idx = json.indexOf(search);
        if (idx < 0) return "";
        int colon = json.indexOf(":", idx + search.length());
        if (colon < 0) return "";
        int start = json.indexOf("\"", colon + 1);
        if (start < 0) return "";
        start++;
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '\\' && i + 1 < json.length()) {
                sb.append(json.charAt(i + 1));
                i++;
            } else if (c == '"') {
                break;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
